// src/components/admin/AdminPanel.jsx
import React from 'react';
import { Route, Switch, useRouteMatch, useHistory } from 'react-router-dom';
import { useAuth } from '../AuthContext'; // Adjust path if necessary
import './AdminPanel.css';

const AdminPanel = () => {
  const { path, url } = useRouteMatch();
  const { user, logout } = useAuth();
  const history = useHistory();

  const handleLogout = () => {
    logout();
    history.push('/'); // Redirect to home or login page after logout
  };

  return (
    <div className="admin-panel-container">
      <header className="admin-header">
        <h1>Admin Panel</h1>
        <div className="admin-header-right">
          {user && (
            <>
              <span className="admin-username">Username: {user.username}</span>
              <button className="logout-button" onClick={handleLogout}>
                Logout
              </button>
            </>
          )}
        </div>
      </header>
      <div className="admin-panel-content">
        <nav className="admin-nav">
          <ul>
            <li><a href={`${url}/orders`}>Orders</a></li>
            <li><a href={`${url}/products`}>Products</a></li>
          </ul>
        </nav>
        <Switch>
          <Route exact path={`${path}/orders`}>
            <div className="admin-section">
              <h2>Orders Section</h2>
              {/* Add Orders content here */}
            </div>
          </Route>
          <Route exact path={`${path}/products`}>
            <div className="admin-section">
              <h2>Products Section</h2>
              {/* Add Products content here */}
            </div>
          </Route>
          <Route exact path={path}>
            <div className="admin-section">
              <h2>Welcome to the Admin Panel</h2>
              {/* Default or Dashboard content */}
            </div>
          </Route>
        </Switch>
      </div>
    </div>
  );
};

export default AdminPanel;

